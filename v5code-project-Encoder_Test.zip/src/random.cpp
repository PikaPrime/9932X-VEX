// /*----------------------------------------------------------------------------*/
// /*                                                                            */
// /*    Module:       main.cpp                                                  */
// /*    Author:       C:\Users\9932X                                            */
// /*    Created:      Thu Oct 13 2022                                           */
// /*    Description:  V5 project                                                */
// /*                                                                            */
// /*----------------------------------------------------------------------------*/

// // ---- START VEXCODE CONFIGURED DEVICES ----
// // Robot Configuration:
// // [Name]               [Type]        [Port(s)]
// // Controller1          controller                    
// // BRmotor              motor         19              
// // FRmotor              motor         20              
// // FLmotor              motor         15              
// // BLmotor              motor         16              
// // EncoderX1            encoder       A, B            
// // EncoderX2            encoder       C, D            
// // EncoderY             encoder       E, F            
// // ---- END VEXCODE CONFIGURED DEVICES ----

// #include "vex.h"

// using namespace vex;

// int main() {
//   // Initializing Robot Configuration. DO NOT REMOVE!
//   vexcodeInit();

//   //Configures orientation and coordinate tracking variables
//   double lastDeg = 0; // saves the last measured orientation of the robot
//   double currentDeg = 0; // the current orientation of the robot
//   double xPos = 0; // the current X position of the robot relative to its starting position
//   double yPos = 0; // the current Y position of the robot relative to its starting position
//   double lastXPos = 0; // saves the last X position of the robot relative to its starting position
//   double lastYPos = 0; // saves the last Y position of the robot relative to its starting position
//   const double xRad = 4.35;  // measurement of half the distance between front-facing tracking wheels
//   const double wheelRad = 1.625; // radius of the tracking wheels

//   //Define previous encoder values
//   double encoderX1LastVal = 0.0; // saves the last measured value of left tracking wheel
//   double encoderX2LastVal = 0.0; // saves the last measured value of right tracking wheel
//   double encoderYLastVal = 0.0; // save the last measured value of right tracking wheel

//   //Instiantiate change in encoder values
//   double encoderChangeX1; // the change in encoder value of left tracking wheel from last measurement to current measurement
//   double encoderChangeX2; // the change in encoder value of right tracking wheel from last measurement to current measurement
//   double encoderChangeY;  // the change in encoder value of back tracking wheel from last measurement to current measurement

//   //Define distance encoder values travel
//   double distanceTraveledX1 = 0.0; //the displacement traveled by the left tracking wheel
//   double distanceTraveledX2 = 0.0; //the displacement traveled by the right tracking wheel
//   double distanceTraveledY = 0.0; //the displacements traveled by the back tracking wheel

//   //  Reset encoder values
//   EncoderX1.resetRotation();
//   EncoderX2.resetRotation();
//   EncoderY.resetRotation();
//   Brain.Screen.clearScreen();
//   while (1) {
//     //Sets up to print measurements to screen
//     Brain.Screen.clearLine(1,color::black);
//     Brain.Screen.clearLine(2,color::black);
//     Brain.Screen.clearLine(3,color::black);
//     Brain.Screen.clearLine(4,color::black);
//     Brain.Screen.setCursor(1,1);    
//     Brain.Screen.print(currentDeg);
//     Brain.Screen.setCursor(2,1);
//     Brain.Screen.print(xPos);
//     Brain.Screen.setCursor(3,1);
//     Brain.Screen.print(yPos);
//     Brain.Screen.setCursor(4,1);
//     Brain.Screen.print(EncoderY.position(deg));
//     Brain.Screen.render();

//     // Calculate the change in encoder values from current to last call
//     encoderChangeX1 = EncoderX1.position(deg) - encoderX1LastVal;
//     encoderChangeX2 = EncoderX2.position(deg) - encoderX2LastVal;
//     encoderChangeY = EncoderY.position(deg) - encoderYLastVal;

//     // Convert encoder change values from degrees to distance values
//     distanceTraveledX1 = encoderChangeX1 * M_PI / 180 * 2 * wheelRad;
//     distanceTraveledX2 = encoderChangeX2 * M_PI / 180 * 2 * wheelRad;
//     distanceTraveledY = encoderChangeY * M_PI / 180 * 2 *  wheelRad;

//     // Set current encoder values to previous encoder values 
//     encoderX1LastVal = EncoderX1.position(deg);
//     encoderX2LastVal = EncoderX2.position(deg);
//     encoderYLastVal = EncoderY.position(deg);

//     // Update previous orientation to current orientation
//     lastDeg = currentDeg;

//     // Update current orientation based on proven formula (keeping in mind that one encoder is inverted)
//     currentDeg = lastDeg + ((distanceTraveledX1 + distanceTraveledX2) / (2 * xRad)) * 90 / M_PI;

//     // Resets the degree values to be always between (0,360)
//     if (currentDeg > 360) 
//     {
//       currentDeg -= 360;
//     }
//     else if (currentDeg < 0)
//     {
//       currentDeg = 360 - currentDeg;
//     }

//     // Determine the change in position and saves those values to new X and Y coordinates
//     if (distanceTraveledX1 || distanceTraveledY)
//     { 
//       xPos = lastXPos + cos(currentDeg * M_PI / 180) * -distanceTraveledX1 + sin(currentDeg * M_PI / 180) * distanceTraveledY;
//       yPos = lastYPos + cos(currentDeg * M_PI / 180) * distanceTraveledY + sin(currentDeg * M_PI / 180) * distanceTraveledX1;
//     }

//     // Save current coordiantes to last coordinates
//     lastXPos = xPos;
//     lastYPos = yPos;
//   }
// }