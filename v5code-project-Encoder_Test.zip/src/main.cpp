/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       C:\Users\Andrew Yuen                                      */
/*    Created:      Thu Oct 13 2022                                           */
/*    Description:  V5 project                                                */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Controller1          controller                    
// BRmotor              motor         19              
// FRmotor              motor         20              
// FLmotor              motor         15              
// BLmotor              motor         16              
// EncoderX1            encoder       A, B            
// EncoderX2            encoder       C, D            
// EncoderY             encoder       E, F            
// lowerIntake          motor         9               
// FlyWheel1            motor         7               
// FlyWheel2            motor         8               
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"
#include "math.h"
// #include "userControl.h"
// #include "odom.h"
using namespace vex;
bool enableDrive = true;

bool toggle = false;
bool stable = false;

// intake L1, intake reverse is L2
int userControl(void)
{
  

// DRIVETRAIN CODE
while (true) {
// Get the velocity percentage of the left motor. (Axis3)
    FLmotor.spin(forward, +Controller1.Axis3.position(pct)+Controller1.Axis1.position(pct), pct);
    BLmotor.spin(forward, +Controller1.Axis3.position(pct)+Controller1.Axis1.position(pct), pct);
    BRmotor.spin(forward, +Controller1.Axis3.position(pct)-Controller1.Axis1.position(pct), pct);
    FRmotor.spin(forward, +Controller1.Axis3.position(pct)-Controller1.Axis1.position(pct), pct);
/*  while(enableDrive){
    // Configure area for deadzone
    if (abs(Controller1.Axis3.position(pct)) > 0 || abs(Controller1.Axis1.position(pct)) > 0){
      FLmotor.spin(forward, +Controller1.Axis1.position(pct)+Controller1.Axis3.position(pct), pct);
      BLmotor.spin(forward, +Controller1.Axis1.position(pct)+Controller1.Axis3.position(pct), pct);
      BRmotor.spin(forward, -Controller1.Axis1.position(pct)+Controller1.Axis3.position(pct), pct);
      FRmotor.spin(forward, -Controller1.Axis1.position(pct)+Controller1.Axis3.position(pct), pct);
    }
    else
    {
      FLmotor.spin(forward,0, (pct));
      BLmotor.spin(forward,0, (pct));
      BRmotor.spin(forward,0, (pct));
      FRmotor.spin(forward,0, (pct));
    }
*/
//INTAKE CODE
    if (Controller1.ButtonL1.pressing() && !Controller1.ButtonL2.pressing())
    {
      lowerIntake.spin(forward, 100, pct);
    }
    else if (Controller1.ButtonL2.pressing() && !Controller1.ButtonL1.pressing())
    {
      lowerIntake.spin(reverse, 100, pct);
    }
    else 
    {
      lowerIntake.spin(forward, 0, pct);
    }

//FLYWHEEL CODE
    while(true){
      if (toggle){
        FlyWheel1.spin(forward, 100, percent);
        FlyWheel2.spin(forward, 100, percent);
      }
      else {
        FlyWheel1.stop();
        FlyWheel2.stop();
      }

      if (Controller1.ButtonR1.pressing()) {
        if(!stable){ 
        //Keeps the toggle actually toggled instead of flipping back and forth with every loop
          toggle = !toggle;
          stable = true;
        }
      } else { 
        //Once the button is pressed again, toggle is released
        stable = false;
      }

    wait(5, msec);
    }
  }
  return 1;
}



//-----------PATRICKS ODOM STUFF----------
double lastDeg = 0;
double currentDeg = 0;
double xPostwo = 0; 
double yPostwo = 0;
double xPos = 0;
double yPos = 0;
double lastXPos = 0;
double lastYPos = 0;
const double xRad = 4.35;
const double wheelRad = 1.625;
//Define previous encoder values
double encoderX1LastVal = 0.0;
double encoderX2LastVal = 0.0;
double encoderYLastVal = 0.0;

//Instiantiate change in encoder values
double encoderChangeX1;
double encoderChangeX2;
double encoderChangeY;

//Define distance encoder values travel
double distanceTraveledX1 = 0.0;
double distanceTraveledX2 = 0.0;
double distanceTraveledX = 0.0;
double distanceTraveledY = 0.0;

int odom(void)
{
  EncoderX1.resetRotation();
  EncoderX2.resetRotation();
  EncoderY.resetRotation();
  Brain.Screen.clearScreen();
  while (1)
    {
    //Sets up to print measurements to screen
    Brain.Screen.clearLine(1,color::black);
    Brain.Screen.clearLine(2,color::black);
    Brain.Screen.clearLine(3,color::black);
    Brain.Screen.clearLine(4,color::black);
    Brain.Screen.setCursor(1,1);    
    Brain.Screen.print("Current degrees %f", currentDeg);
    Brain.Screen.setCursor(2,1);
    Brain.Screen.print("Current xPos %f", xPos);
    Brain.Screen.setCursor(3,1);
    Brain.Screen.print("Current yPos %f", yPos);
    Brain.Screen.setCursor(4,1);
    Brain.Screen.print(EncoderY.position(deg));
    Brain.Screen.render();

    encoderChangeX1 = EncoderX1.position(deg) - encoderX1LastVal;
    encoderChangeX2 = EncoderX2.position(deg) - encoderX2LastVal;
    encoderChangeY = EncoderY.position(deg) - encoderYLastVal;

    //Convert encoder change to distance values
    distanceTraveledX1 = encoderChangeX1 * M_PI / 180 * 2 * wheelRad;
    distanceTraveledX2 = encoderChangeX2 * M_PI / 180 * 2 * wheelRad;
    if (distanceTraveledX1 >= distanceTraveledX2)
    {
      distanceTraveledX = distanceTraveledX1 - (xRad * (currentDeg - lastDeg) * M_PI) / 360; 
    }
    else {
      distanceTraveledX = distanceTraveledX2 - (xRad * (currentDeg - lastDeg) * M_PI) / 360; 
    }
    distanceTraveledY = encoderChangeY * M_PI / 180 * 2 *  wheelRad;

    //Set encoder values to previous encoder values 
    encoderX1LastVal = EncoderX1.position(deg);
    encoderX2LastVal = EncoderX2.position(deg);
    encoderYLastVal = EncoderY.position(deg);

    // encoderYLastVal = EncoderY.position(deg);
    //Update previous orientation and current orientation
    lastDeg = currentDeg;
    currentDeg = lastDeg + ((distanceTraveledX1 + distanceTraveledX2) / (2 * xRad)) * 90 / M_PI;
    if (currentDeg > 360) 
    {
      currentDeg -= 360;
    }
    else if (currentDeg < 0)
    {
      currentDeg += 360;
    }
    //Determine the change in position
    if (distanceTraveledX1 || distanceTraveledY)
    { 
      xPostwo = lastXPos + cos(currentDeg * M_PI / 180) * distanceTraveledX + sin(currentDeg * M_PI / 180) * distanceTraveledY;
      yPostwo = lastYPos + cos(currentDeg * M_PI / 180) * distanceTraveledY + sin(currentDeg * M_PI / 180) * distanceTraveledX;
    }
    lastXPos = xPostwo;
    lastYPos = yPostwo;
    xPos = xPostwo / 2;
    yPos = -yPostwo / 2;
     // Sleep the task for a short amount of time to
    vex::task::sleep(50); // Sleep the task for a short amount of time to
    }
  return 1;
}

double errorProp = 0;
double errorIntegral = 0;
double errorDerivative = 0;
double lastError = 0;
double desiredAngle = 0;
bool enablePIDturn = true;
int PID_turn(void)
{
//kU = 1.9
//pU = 0.8
  // declare kP, kI, and kD values
  double kP = 0.5;
  double kI = 0.0;
  double kD = 0.15;
  
  // PID is motorPower = kP * Proportion error + kI * summation of error + kD * (current_error - last_error)
  while (enablePIDturn){
    lastError = errorProp; // save last error as current error
    errorProp = desiredAngle - currentDeg; // find current error by substracting current from desired angle
    
    //ensures that the turn will always be less than 180 degrees
    if ((desiredAngle - currentDeg) > 180)
    {
      errorProp = (desiredAngle - currentDeg) - 360;
    }
    if ((desiredAngle - currentDeg) < (-180))
    {
      errorProp = (desiredAngle - currentDeg) + 360;
    }

    errorIntegral += errorProp; //adds to the integral sum
    errorDerivative = errorProp - lastError; // finds the change in error (used to correct proportion and integral sum)

    double motorPower = errorProp * kP + errorIntegral * kI + errorDerivative * kD; // determines motor power
    FLmotor.spin(reverse, motorPower, pct);
    BLmotor.spin(reverse, motorPower, pct);
    BRmotor.spin(forward, motorPower, pct);
    FRmotor.spin(forward, motorPower, pct);
    vex::task::sleep(70); // sleep task for 70ms to allow for values to change before next call
  }
  return 1;
}

/////////////////////////////////////////////////////////////////
// PID - Fixes errors in auton driving
/////////////////////////////////////////////////////////////////

//settings
//TODO: kP, kI, kD -> need to test different values
double kP = 0.01; // error -> 1) change until steady, minor osciliations
double kI = 0.00000; // minor corrections -> 3) increase to increase precision
double kD = 0.01; //speeds up or slows down based on too fast or too slow -> 2) increase val until ociliation no longer become oscilations

double otherkI = 0.0001;
double otherkD = 0.00001;

//Autonomous Settings
double desiredDistance = 0;
double errorProportional = 0;
double totalError = 0;
double errorDer = 0;
double prevError = 0;
double encoderCurrentError = 0;
//if encoders arent moving at the same speed = error
bool enableDrivePID = true;
bool resetRotationDeg = false;
int drivePID(void){
  EncoderX1.resetRotation();
  EncoderX2.resetRotation();
  while(enableDrivePID){
    if (resetRotationDeg)
    {
      EncoderX1.resetRotation();
      EncoderX2.resetRotation();
    }
    // int leftEncoderPosition = EncoderX1.position(degrees);
    // int rightEncoderPosition = EncoderX2.position(degrees);
    int leftMotorPosition = BLmotor.position(degrees);
    int rightMotorPosition = BRmotor.position(degrees);
    

    int averagePosition = (abs(leftMotorPosition) + abs(rightMotorPosition))/2;

    errorProportional = averagePosition - desiredDistance;

    errorDer = errorProportional - prevError;

    totalError += errorProportional;

    double motorPower = errorProportional * kP + errorDer * kD + totalError * kI; 

    BLmotor.spin(forward, motorPower, voltageUnits::volt);
    BRmotor.spin(forward, motorPower, voltageUnits::volt);
    FLmotor.spin(forward, motorPower, voltageUnits::volt);
    FRmotor.spin(forward, motorPower, voltageUnits::volt);
    prevError = errorProportional;
    vex::task::sleep(70);
  }
  return 1;
}

int main() {
  vexcodeInit();
  enablePIDturn = false;
  vex::task odometry(odom); //start odometry task
  vex::task control(userControl); // start userControl task
 // vex::task dPid(drivePID);

 // vex::task::sleep(6000);
  // enableDrive = false;
  // vex::task turnpid(PID_turn);
  // desiredAngle = 90;
  // vex::task::sleep(3000);
  // desiredAngle = 180;
  // vex::task::sleep(3000);
  // desiredAngle = 270;
  // vex::task::sleep(3000);
  // desiredAngle = 0;
  // vex::task::sleep(3000);
  // desiredAngle = 270;
  // vex::task::sleep(3000);
  // desiredAngle = 180;
  // vex::task::sleep(3000);
  // desiredAngle = 90;
  // vex::task::sleep(3000);
  // desiredAngle = 0;
  // enablePIDturn = false;
  // FLmotor.spin(reverse, 50, pct);
  // BLmotor.spin(reverse, 50, pct);
  // BRmotor.spin(forward, 50, pct);
  // FRmotor.spin(forward, 50, pct);



  // vex::task c(userControl);
  // Initializing Robot Configuration. DO NOT REMOVE!

  // Deadzone stops the motors when Axis values are close to zero to provide smoother driver control with a joystick
// and prevent accidental twitches or joystick errors from adversely affecting robot movement.
  // double lastDeg = 0;
  // double currentDeg = 0;
  // double xPostwo = 0; 
  // double yPostwo = 0;
  // double xPos = 0;
  // double yPos = 0;
  // double lastXPos = 0;
  // double lastYPos = 0;
  // const double xRad = 4.375;
  // const double wheelRad = 1.625;
  // //Define previous encoder values
  // double encoderX1LastVal = 0.0;
  // double encoderX2LastVal = 0.0;
  // double encoderYLastVal = 0.0;

  // //Instiantiate change in encoder values
  // double encoderChangeX1;
  // double encoderChangeX2;
  // double encoderChangeY;

  // //Define distance encoder values travel
  // double distanceTraveledX1 = 0.0;
  // double distanceTraveledX2 = 0.0;
  // double distanceTraveledY = 0.0;
  //  Reset encoder values
  // while (currentDeg < 60) {
    //Insert Drive Code Here
    ///
    //Change in encoder values in degrees
    // Brain.Screen.clearLine(1,color::black);
    // Brain.Screen.clearLine(2,color::black);
    // Brain.Screen.clearLine(3,color::black);
    // Brain.Screen.clearLine(4,color::black);
    // Brain.Screen.setCursor(1,1);    
    // Brain.Screen.print(currentDeg);
    // Brain.Screen.setCursor(2,1);
    // Brain.Screen.print(xPos);
    // Brain.Screen.setCursor(3,1);
    // Brain.Screen.print(yPos);
    // Brain.Screen.setCursor(4,1);
    // Brain.Screen.print(EncoderY.position(deg));
    // Brain.Screen.render();

    // encoderChangeX1 = EncoderX1.position(deg) - encoderX1LastVal;
    // encoderChangeX2 = EncoderX2.position(deg) - encoderX2LastVal;
    // encoderChangeY = EncoderY.position(deg) - encoderYLastVal;

    // //Convert encoder change to distance values
    // distanceTraveledX1 = encoderChangeX1 * M_PI / 180 * 2 * wheelRad;
    // distanceTraveledX2 = encoderChangeX2 * M_PI / 180 * 2 * wheelRad;
    // distanceTraveledY = encoderChangeY * M_PI / 180 * 2 *  wheelRad;

    // //Set encoder values to previous encoder values 
    // encoderX1LastVal = EncoderX1.position(deg);
    // encoderX2LastVal = EncoderX2.position(deg);
    // encoderYLastVal = EncoderY.position(deg);

    // // encoderYLastVal = EncoderY.position(deg);
    // //Update previous orientation and current orientation
    // lastDeg = currentDeg;
    // currentDeg = lastDeg + ((distanceTraveledX1 + distanceTraveledX2) / (2 * xRad)) * 90 / M_PI;
    // if (currentDeg > 360) 
    // {
    //   currentDeg -= 360;
    // }
    // else if (currentDeg < 0)
    // {
    //   currentDeg = 360 - currentDeg;
    // }
    // //Determine the change in position
    // if (distanceTraveledX1 || distanceTraveledY)
    // { 
    //   xPostwo = lastXPos + cos(currentDeg * M_PI / 180) * -distanceTraveledX1 + sin(currentDeg * M_PI / 180) * distanceTraveledY;
    //   yPostwo = lastYPos + cos(currentDeg * M_PI / 180) * distanceTraveledY + sin(currentDeg * M_PI / 180) * distanceTraveledX1;
    // }
    // lastXPos = xPostwo;
    // lastYPos = yPostwo;
    // xPos = xPostwo / 2;
    // yPos = -yPostwo / 2;
    // arcade_control(); 
    // wait(10, msec); // Sleep the task for a short amount of time to




  //   FLmotor.spin(reverse, motorPower, pct);
  //   BLmotor.spin(reverse, motorPower, pct);
  //   BRmotor.spin(forward, motorPower, pct);
  //   FRmotor.spin(forward, motorPower, pct);
  //   wait(10, msec);
  // }
  // FLmotor.spin(reverse, 0, pct);
  // BLmotor.spin(reverse, 0, pct);
  // BRmotor.spin(forward, 0, pct);
  // FRmotor.spin(forward, 0, pct);
// int deadzone = 2;

// while (true) {
// // Get the velocity percentage of the left motor. (Axis3)
//     LeftFront.spin(forward, +Controller1.Axis3.position(pct)+Controller1.Axis1.position(pct), pct);
//     LeftBack.spin(forward, +Controller1.Axis3.position(pct)+Controller1.Axis1.position(pct), pct);
//     RightFront.spin(forward, +Controller1.Axis3.position(pct)-Controller1.Axis1.position(pct), pct);
//     RightBack.spin(forward, +Controller1.Axis3.position(pct)-Controller1.Axis1.position(pct), pct);
/*
int leftSideSpeed = Controller1.Axis3.position(pct);
// Get the velocity percentage of the right motor. (Axis2)
int rightSideSpeed = Controller1.Axis2.position(pct);
// Set the speed of the left motor. If the value is less than the deadzone, set it to zero.
  if (abs(leftSideSpeed) < deadzone) {
  // Set the speed to zero.
  LeftFront.setVelocity(0, percent);
  LeftBack.setVelocity(0, percent);

  } else {
  // Set the speed to leftMotorSpeed
  LeftFront.setVelocity(leftSideSpeed, percent);
  LeftBack.setVelocity(leftSideSpeed, percent);
  }

// Set the speed of the right motor. If the value is less than the deadzone, set it to zero.
  if (abs(rightSideSpeed) < deadzone) {
  // Set the speed to zero
  RightFront.setVelocity(0, percent);
  RightBack.setVelocity(0, percent);
  } else {
  // Set the speed to rightMotorSpeed
  RightFront.setVelocity(rightSideSpeed, percent);
  RightBack.setVelocity(rightSideSpeed, percent);
  }

  // Spin both motors in the forward direction.
  LeftFront.spin(forward);
  LeftBack.spin(forward);
  RightFront.spin(forward);
  RightBack.spin(forward);

wait(20, msec);
}
*/
}