// #include "userControl.h"

// void userControl::arcadeControl(void)
// {
//   while(1){
//     if (abs(Controller1.Axis3.position(pct)) > 5 || abs(Controller1.Axis1.position(pct)) > 5){
//       FLmotor.spin(forward, +Controller1.Axis1.position(pct)+Controller1.Axis3.position(pct), pct);
//       BLmotor.spin(forward, +Controller1.Axis1.position(pct)+Controller1.Axis3.position(pct), pct);
//       BRmotor.spin(forward, -Controller1.Axis1.position(pct)+Controller1.Axis3.position(pct), pct);
//       FRmotor.spin(forward, -Controller1.Axis1.position(pct)+Controller1.Axis3.position(pct), pct);
//       wait(20, msec); // Sleep the task for a short amount of time to
//                       // prevent wasted resources. Do not delete.
//     }
//     else 
//     {
//       FLmotor.spin(forward, 0, pct);
//       BLmotor.spin(forward, 0, pct);
//       BRmotor.spin(forward, 0, pct);
//       FRmotor.spin(forward, 0, pct);
//     }
//   }
// }