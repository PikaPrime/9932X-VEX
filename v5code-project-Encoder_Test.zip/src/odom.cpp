// #include "vex.h"
// #include "odom.h"


// double lastDeg = 0;
// double currentDeg = 0;
// double xPostwo = 0; 
// double yPostwo = 0;
// double xPos = 0;
// double yPos = 0;
// double lastXPos = 0;
// double lastYPos = 0;
// const double xRad = 4.375;
// const double wheelRad = 1.625;
// //Define previous encoder values
// double encoderX1LastVal = 0.0;
// double encoderX2LastVal = 0.0;
// double encoderYLastVal = 0.0;

// //Instiantiate change in encoder values
// double encoderChangeX1;
// double encoderChangeX2;
// double encoderChangeY;

// //Define distance encoder values travel
// double distanceTraveledX1 = 0.0;
// double distanceTraveledX2 = 0.0;
// double distanceTraveledY = 0.0;

// int odom::odomController()
// {
//     Brain.Screen.clearLine(1,color::black);
//     Brain.Screen.clearLine(2,color::black);
//     Brain.Screen.clearLine(3,color::black);
//     Brain.Screen.clearLine(4,color::black);
//     Brain.Screen.setCursor(1,1);    
//     Brain.Screen.print(currentDeg);
//     Brain.Screen.setCursor(2,1);
//     Brain.Screen.print(xPos);
//     Brain.Screen.setCursor(3,1);
//     Brain.Screen.print(yPos);
//     Brain.Screen.setCursor(4,1);
//     Brain.Screen.print(EncoderY.position(deg));
//     Brain.Screen.render();

//     encoderChangeX1 = EncoderX1.position(deg) - encoderX1LastVal;
//     encoderChangeX2 = EncoderX2.position(deg) - encoderX2LastVal;
//     encoderChangeY = EncoderY.position(deg) - encoderYLastVal;

//     //Convert encoder change to distance values
//     distanceTraveledX1 = encoderChangeX1 * M_PI / 180 * 2 * wheelRad;
//     distanceTraveledX2 = encoderChangeX2 * M_PI / 180 * 2 * wheelRad;
//     distanceTraveledY = encoderChangeY * M_PI / 180 * 2 *  wheelRad;

//     //Set encoder values to previous encoder values 
//     encoderX1LastVal = EncoderX1.position(deg);
//     encoderX2LastVal = EncoderX2.position(deg);
//     encoderYLastVal = EncoderY.position(deg);

//     // encoderYLastVal = EncoderY.position(deg);
//     //Update previous orientation and current orientation
//     lastDeg = currentDeg;
//     currentDeg = lastDeg + ((distanceTraveledX1 + distanceTraveledX2) / (2 * xRad)) * 90 / M_PI;
//     if (currentDeg > 360) 
//     {
//       currentDeg -= 360;
//     }
//     else if (currentDeg < 0)
//     {
//       currentDeg += 360;
//     }
//     //Determine the change in position
//     if (distanceTraveledX1 || distanceTraveledY)
//     { 
//       xPostwo = lastXPos + cos(currentDeg * M_PI / 180) * -distanceTraveledX1 + sin(currentDeg * M_PI / 180) * distanceTraveledY;
//       yPostwo = lastYPos + cos(currentDeg * M_PI / 180) * distanceTraveledY + sin(currentDeg * M_PI / 180) * distanceTraveledX1;
//     }
//     lastXPos = xPostwo;
//     lastYPos = yPostwo;
//     xPos = xPostwo / 2;
//     yPos = -yPostwo / 2;
//      // Sleep the task for a short amount of time to

//     return currentDeg;
// }